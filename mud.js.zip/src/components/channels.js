import React from 'react';

export default function Channels(props) {
    return <div/>;
}